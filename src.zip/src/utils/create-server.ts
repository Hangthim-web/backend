import { config } from 'dotenv'
import cors from 'cors'
import express, { Request, Response } from 'express'
import crypto from 'crypto'
import userRoutes from '../routes/user.routes'
import routes from '../routes/index'
import * as ErrorMiddleWares from '../middleware/errors.middleware'

config()

const aVAr = express()

console.log('Hello this is me')

aVAr.use(express.json())
aVAr.use(express.urlencoded({ extended: true }))
aVAr.use(cors())
aVAr.use('/api', routes)

// interface Todo {
//     id: string
//     name: string
//     active: boolean
// }

// interface TodoRequestBody {
//     name: string
//     active: boolean
// }

// const users: Todo[] = [
//     { id: crypto.randomUUID(), name: 'just a thing', active: true },
// ]

aVAr.get('/users', userRoutes)

aVAr.use(ErrorMiddleWares.methodNotAllowed)
aVAr.use(ErrorMiddleWares.genericErrorHandler)

export default aVAr
