import { Router } from 'express'
import {
    createUser,
    getUser,
    deleteUser,
    updateUser,
    loginUser
} from '../controllers/user.controller'
// import { loginUser } from '../services/user.loginService'
import { validate } from '../utils/validate'
import { createPostDto } from '../validators/user.validators'
import * as postController from '../controllers/user.controller'

const router = Router()

router.get('/', getUser)

// router.post('/signup')

router.post('/', validate(createPostDto), postController.createUser)

router.delete('/:id', deleteUser)

router.post('/:login', loginUser)

router.patch('/:id', updateUser)
//z
// router.post('/', (req, res, next) => {

// })

export default router
